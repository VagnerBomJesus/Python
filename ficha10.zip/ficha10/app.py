import pandas as pd
#import plotly.express as px
tabela = pd.read_csv('xpto_users.csv')
display(tabela)
